ant compile && java -jar dist/kingsheep.jar res/test3.map Eyjafjallajokull Human
