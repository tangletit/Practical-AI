ant compile && java -jar dist/kingsheep.jar res/divided.map Eyjafjallajokull Human
