ant compile && java -jar dist/kingsheep.jar res/maze.map Eyjafjallajokull Eyjafjallajokull
