ant compile && java -jar dist/kingsheep.jar res/maze2.map Eyjafjallajokull Eyjafjallajokull
