ant compile && java -jar dist/kingsheep.jar res/heaven.map Eyjafjallajokull Eyjafjallajokull
