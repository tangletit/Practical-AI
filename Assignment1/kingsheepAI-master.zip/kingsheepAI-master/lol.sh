ant compile && java -jar dist/kingsheep.jar res/lol.map Eyjafjallajokull Eyjafjallajokull
