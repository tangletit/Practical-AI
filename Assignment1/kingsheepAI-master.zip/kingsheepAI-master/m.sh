ant compile && java -jar dist/kingsheep.jar res/test.map Eyjafjallajokull p2
