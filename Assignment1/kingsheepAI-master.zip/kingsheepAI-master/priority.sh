ant compile && java -jar dist/kingsheep.jar res/priority.map Eyjafjallajokull awesome
