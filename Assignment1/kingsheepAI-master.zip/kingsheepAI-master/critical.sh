ant compile && java -jar dist/kingsheep.jar res/critical.map Eyjafjallajokull Eyjafjallajokull
