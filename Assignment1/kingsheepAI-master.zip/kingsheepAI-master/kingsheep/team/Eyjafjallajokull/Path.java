package kingsheep.team.Eyjafjallajokull;

interface Path {
	//void setTarget(int fromy, int fromX, int toY, int toX);

	//Returns direction in int[] (Creature format)
	int[] getDirection();

}
