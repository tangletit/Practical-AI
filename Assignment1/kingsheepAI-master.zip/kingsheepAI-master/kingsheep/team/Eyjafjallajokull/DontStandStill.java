package kingsheep.team.Eyjafjallajokull;
import kingsheep.*;
//import java.lang.Enum;

class DontStandStill implements Algorithm {

	public int[] calculate(Type map[][], AI parent) {
		int toReturn[] = new int[5];
		toReturn[0] = -100;	
		return toReturn;
	}

	public double getMultiplyer() {
		return 0.1f;
	}

	public String getName() {
		return "dontStandStill";
	}
}
