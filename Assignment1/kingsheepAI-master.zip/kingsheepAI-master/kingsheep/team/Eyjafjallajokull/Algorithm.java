package kingsheep.team.Eyjafjallajokull;
import kingsheep.*;

interface Algorithm {

	public int[] calculate(Type map[][], AI parent);
	public double getMultiplyer();
	public String getName();

}
