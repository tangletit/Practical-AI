package kingsheep.team.test;
import kingsheep.*;

interface Algorithm {

	//Algorithm();

	public int[] calculate(Type map[][], Creature parent);
	public double getMultiplyer();
	public String getName();


}
