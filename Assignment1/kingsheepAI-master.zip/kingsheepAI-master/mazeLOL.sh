ant compile && java -jar dist/kingsheep.jar res/mazeLOL.map Eyjafjallajokull Human
