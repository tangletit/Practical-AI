ant compile && java -jar dist/kingsheep.jar res/test2.map Eyjafjallajokull Eyjafjallajokull
